This Project Contains two folder
App1 and App2
App1 is for jsp files i.e. frontend
App2 is for backend using spring boot and hibernate